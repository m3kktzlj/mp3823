<?php
needRole('vhost');
define('BEGIN', 'BEGIN');
define('TABLENAME', '!anticc');
define('ACTION', 'table:!anticc');
class AnticcControl extends Control
{
	private $access;

	public function __construct()
	{
		parent::__construct();
		load_lib('pub:access');
		$this->access = new Access(getRole('vhost'));
	}

	public function anticcFrom()
	{
		$user = daocall('vhost', 'getVhost', array(getRole('vhost')));

		$this->anticcAddTable();

		if ($this->access->findChain(BEGIN, TABLENAME)) {
			$this->_tpl->assign('at', 1);
		}

		$result = $this->access->listChain(TABLENAME);

		if ($result) {
			foreach ($result->children() as $chain) {
				foreach ($chain->children() as $name=>$ch) {
					if($name == 'mark_anti_cc'){
						$msg = file_get_contents($user['doc_root'] . '/access.xml');
						preg_match("/<html id=\'anticc_(.*?)\'>/", $msg, $match);
						$mode = $match[1];
						$cc = array('request' => (string) $ch['request'], 'second' => (string) $ch['second'], 'wl' => (string) $ch['wl'], 'flush' => (string) $ch['flush'], 'fix_url' => (string) $ch['fix_url'], 'skip_cache' => (string) $ch['skip_cache'], 'mode' => $mode);

						$this->_tpl->assign('cc', $cc);
					}elseif($name == 'acl_srcs'){
						$this->_tpl->assign('whiteip', str_replace('|',"\r\n",$ch));
					}
				}
			}
		}

		return $this->_tpl->fetch('anticc/anticcfrom.html');
	}

	public function anticcAdd()
	{
		$check_result = apicall('access', 'checkAccess', array('ent'));

		if ($check_result !== true) {
			exit($check_result);
		}

		$mode = trim($_REQUEST['mode']);

		switch ($mode) {
		case 'http_redirect':
			$msg = "HTTP/1.1 302 FOUND\r\nConnection: keep-alive\r\nCache-Control: no-cache,no-store\r\nLocation: {{url}}\r\n\r\n<html id='anticc_http_redirect'><body><a href='{{url}}'>continue</a></body></html>";
			break;

		case 'js_concat':
			$msg = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: keep-alive\r\nCache-Control: no-cache,no-store\r\n\r\n<html id='anticc_js_concat'><body><script language='javascript'>{{revert:url}};window.location=url;</script></body></html>";
			break;

		default:
			exit('未知防护模式');
		}

		$this->access->delChainByName(TABLENAME, TABLENAME);

		$request = intval($_REQUEST['request']);
		$second = intval($_REQUEST['second']);
		$whiteip = $_REQUEST['whiteip'];
		if(!empty($whiteip)){
			$whiteip = str_replace(array("\r\n", "\r", "\n"), "|", $whiteip);
			$arrs = explode("|",$whiteip);
			$ipdata = '';
			foreach($arrs as $ip){
				$ip = trim($ip);
				if(empty($ip) || !strpos($ip,'.'))continue;
				$ipdata .= $ip . '|';
			}
			$ipdata = trim($ipdata, '|');
		}

		$wl = 1;
		$fix_url = 1;
		$skip_cache = 1;
		$arr['action'] = 'continue';
		$arr['name'] = TABLENAME;
		if(!empty($ipdata)){
			$modeles['acl_srcs'] = array('revers' => 1, 'split' => '|', 'v' => $ipdata);
		}
		$modeles['mark_anti_cc'] = array('request' => $request, 'second' => $second, 'wl' => $wl, 'fix_url' => $fix_url, 'skip_cache' => $skip_cache, 'msg' => $msg);
		$result = $this->access->addChain(TABLENAME, $arr, $modeles);

		if (!$result) {
			exit('保存设置失败');
		}

		apicall('vhost', 'updateVhostSyncseq', array(getRole('vhost')));
		exit('成功');
	}

	/**
	 * 开关
	 * Enter description here ...
	 */
	public function anticcCheckOn()
	{
		$status = intval($_REQUEST['status']);

		switch ($status) {
		case '2':
			$this->access->delChainByName(BEGIN, TABLENAME);
			break;

		case '1':
			$arr = array('action' => ACTION, 'name' => TABLENAME);
			$this->access->addChain(BEGIN, $arr);
			break;

		default:
			break;
		}

		apicall('vhost', 'updateVhostSyncseq', array(getRole('vhost')));
		exit('成功');
	}

	public function anticcDel()
	{
		if ($this->access->delChainByName(TABLENAME, TABLENAME)) {
			apicall('vhost', 'updateVhostSyncseq', array(getRole('vhost')));
			exit('成功');
		}

		exit('删除失败');
	}

	private function anticcAddChain()
	{
		if ($this->access->findChain(BEGIN, TABLENAME)) {
			return true;
		}

		$arr = array('action' => ACTION, 'name' => TABLENAME);
		$this->access->addChain(BEGIN, $arr);
	}

	/**
	 * 创建表
	 * Enter description here ...
	 */
	private function anticcAddTable()
	{
		$tables = $this->access->listTable();
		$table_finded = false;

		foreach ($tables as $table) {
			if ($table == TABLENAME) {
				$table_finded = true;
				break;
			}
		}

		if (!$table_finded) {
			if (!$this->access->addTable(TABLENAME)) {
				return $this->show_msg('不能增加表');
			}
		}
	}

	private function show_msg($msg)
	{
		$this->_tpl->assign('msg', $msg);
		return $this->_tpl->fetch('msg.html');
	}
}

?>