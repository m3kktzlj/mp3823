<?php
function php_precreate($params)
{
	$default_version = daocall('setting', 'get', array('default_version'));
	if(!$default_version) $default_version = 'php56';

	if ($params['resync']==1) {

		$vhostinfo = apicall('vhostinfo', 'get2', array($params['name'], 'moduleversion', 101));
		$value = $vhostinfo['value'];
		if(!$value) $value = $default_version;
		apicall('vhost', 'addInfo', array($params['name'], '1,php', 3, '1,cmd:'.$value.',*', false));
		apicall('vhost', 'addInfo', array($params['name'], 'moduleversion', 101, $value, false));

	}else{

		apicall('vhost', 'addInfo', array($params['name'], '1,php', 3, '1,cmd:'.$default_version.',*', false));
		apicall('vhost', 'addInfo', array($params['name'], 'moduleversion', 101, $default_version, false));

		if ($params['default_index']) {
			$default_indexs = explode(',', $params['default_index']);
			$indexs = array();
			$i = 100;

			foreach ($default_indexs as $index) {
				$indexs[] = array($index, 2, $i++, false);
			}
		}
		else {
			$indexs = array(
				array('index.htm', 2, '100', false),
				array('index.html', 2, '101', false),
				array('index.php', 2, '102', false)
				);
		}

		apicall('vhost', 'addInfos', array($params['name'], $indexs));
	}
}

function php_postcreate($params)
{
}

function php_get_version()
{
	$extdir = $GLOBALS['safe_dir'] . '../ext/';
	$opdir = opendir($extdir);

	if (!$opdir) {
		return false;
	}

	while (($file = readdir($opdir)) !== false) {
		if ($file == '.' || $file == '..') {
			continue;
		}

		if (!is_dir($extdir . $file) || !strstr($file, 'php')) {
			continue;
		}

		if (substr($file, 0, 4) == 'tpl_') {
			$file = substr($file, 4);
			if (is_win() && $file == 'php5217') {
				$versions['php52'] = 'php52';
			}
			else {
				$versions[$file] = $file;
			}
		}
		else {
			$versions[$file] = $file;
		}
	}

	return $versions;
}

function php_destroy($params)
{
}

function php_link($params)
{
	$versions = php_get_version();
	sort($versions);

	if (1 < count($versions)) {
		$vhostinfo = apicall('vhostinfo', 'get2', array(getRole('vhost'), 'moduleversion', 101));
		$value = $vhostinfo['value'];
		$str = '<form action=\'?c=index&a=module&op=php_version\' method=\'POST\'>切换php版本:<select name=v>';

		foreach ($versions as $v) {
			$str .= '<option value=\'' . $v . '\' ';

			if ($value == $v) {
				$str .= 'selected';
			}

			$str .= '>' . $v . '</option>';
		}

		$str .= '</select><input value=\'确定\' type=\'submit\'></form>';
	}

	return $str;
}

function php_update($params)
{
}

function php_cron($params)
{
}

function php_call($params)
{
	if ($_REQUEST['op'] == 'php_version') {
		$v = trim($_REQUEST['v']);
		if(empty($v))return false;
		$vhost = getRole('vhost');
		$ver = php_get_version();
		$v = $ver[$v];
		$arr['value'] = '1,cmd:' . $v . ',*';

		if (!apicall('vhost', 'updateInfo', array($vhost, '1,php', $arr, 3))) {
		}

		if (!apicall('vhostinfo', 'set2', array($vhost, 'moduleversion', 101, $v))) {
		}
	}
}


?>
